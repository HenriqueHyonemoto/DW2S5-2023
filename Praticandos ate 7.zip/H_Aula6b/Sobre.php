<?php
require 'header.php';
?>
<div class="sobre">
            <div class="bg-light p-4 mb-4 rounded">
            <h1 class="text-center">Sobre</h1>
            </div>
            <img class="mx-auto img-lorem img-thumbnail m-1 rounded d-block text-center" src="duality.png" alt="Duality" style = "width:600px ">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sit amet egestas sapien. Fusce porttitor tellus vel eleifend dictum. Aenean sed neque sit amet risus eleifend pulvinar. Aliquam erat volutpat. Duis tempor non risus sit amet accumsan. Ut eget nisl ipsum. Morbi ultrices nec mi vitae maximus. Morbi nec ornare justo. Pellentesque aliquam ex eget purus tempor sodales. In imperdiet sem nibh, eget faucibus tortor aliquam eget.
            </p>

            
            <p>
               Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellendus minima error atque commodi earum distinctio. Iure nihil ut quod doloremque, debitis, ullam ducimus, esse dignissimos fugit deserunt dolorem dolores vitae.
            </p>
        </div>
        <?php
require 'footer.php';
?>