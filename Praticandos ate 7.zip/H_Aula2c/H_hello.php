<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initical-scale=1.0">
    <title>>Minha primeira pagina PHP</title>
</head>

<body>
    <h1>Minha primeira pagina PHP</h1>

    <?php

    echo "Hello world!";

    ?>
</body>

</html>